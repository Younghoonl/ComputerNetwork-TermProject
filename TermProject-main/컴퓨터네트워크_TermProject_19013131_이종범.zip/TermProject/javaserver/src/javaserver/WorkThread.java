package javaserver;

import java.io.IOException;

import javax.swing.DefaultListModel;

public class WorkThread extends Thread{
	JavaServer server;
	int count=0;
	DefaultListModel<String> guiModel;
	public WorkThread(JavaServer jas, DefaultListModel<String> model) {
		this.server = jas;
		this.guiModel = model;
	}
	public void conn() throws IOException, InterruptedException {
		server.connect();
	}
	
	public void disc() throws IOException, InterruptedException{
		server.disconnect();
	}
}
