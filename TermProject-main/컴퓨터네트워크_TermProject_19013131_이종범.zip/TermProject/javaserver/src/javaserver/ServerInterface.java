package javaserver;

public interface ServerInterface extends RootServerInterface{
	abstract boolean isNumber(String msg);
}
