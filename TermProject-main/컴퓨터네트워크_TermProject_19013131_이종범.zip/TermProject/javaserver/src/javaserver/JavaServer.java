
 package javaserver;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.regex.Pattern;

//서버 클래스.

public class JavaServer implements RootServerInterface{
	int clientNo;
	private int portNumber;
	private ServerSocket svSocket = null; //클라이언트와 통신 하기 위한 소켓 
	private static Pattern pattern = Pattern.compile("-?\\d+(\\.\\d+)?");
	private static List<ChildThread> clients = new ArrayList<ChildThread>();
	private MsgDelivGui guiPrintText;
	private boolean flag = true;
	public JavaServer() {}
	public JavaServer(int port) throws IOException {
		this.portNumber = port;
//		initServer();
	}
	

	
	protected void initServer() {
		clientNo = 0;
		try { 
			svSocket = new ServerSocket(portNumber);
		} 
		catch (IOException e) { // TODO Auto-generated catch block
			e.printStackTrace(); 
		}
	}
	
	protected void connect() { 
		guiPrintText.printInit();
//		System.out.println("서버 실행합니다.");
		while(true) {
			try { 
				System.out.println("wait...");
				Socket socket = svSocket.accept();
				ChildThread ct = new ChildThread(socket, ++clientNo, guiPrintText);
				guiPrintText.printMsg(toGui("ROOT", String.valueOf(clientNo)));
				ct.setName("Client-Thread-"+clientNo);
				ct.start();
				clients.add(ct);
//				System.out.println(clientNo +" Enter. clients number ="+clients.size());
			} catch (IOException e) { 
				System.out.println("Oh my gosh!");
				e.printStackTrace();
				break;
//				try {
//					disconnect();
//				} catch (IOException | InterruptedException e1) {
//					// TODO Auto-generated catch block
//					e1.printStackTrace();
//				}
			}
		}

	}
	
	protected void disconnect() {
		System.out.println("disconnect() called");

		if(!svSocket.isClosed()) {
			System.out.println("SvSocket is Not Null");
			if(!clients.isEmpty()) {
				System.out.println("들어와있는 클라이언트 수 : "+clients.size());
				while(!clients.isEmpty()) {
					ChildThread e = clients.remove(0);
					try {
						e.infoDisconnect();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						System.out.println("[JavaServer] A critical Remove error occurs.");
						e1.printStackTrace();
					}
				}

			}else {
				System.out.println("클라이언트 0명입니다.");
				
			}
			try {
				
				svSocket.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		
	}
	
	public static List<ChildThread> getClients(){
		return Objects.requireNonNull(clients);
	}
	
	
	protected static boolean isNumber(String sno) {
		if(sno == null)
			return false;
		return pattern.matcher(sno).matches();
	}
	
	protected ServerSocket getSvSocket() {
		return this.svSocket;
	}
	
	protected void setMsgDelivGui(MsgDelivGui g) {
		this.guiPrintText = g;
	}
	
	protected void setServerOn(boolean b ) {
		this.flag = b;
	}

	@Override
	public void toClient(String msg) {
		// TODO Auto-generated method stub
		
	}

}
 
