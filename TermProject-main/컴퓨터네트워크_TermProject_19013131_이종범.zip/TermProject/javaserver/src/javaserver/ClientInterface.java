package javaserver;

public interface ClientInterface{
	void toServer(String msg);
}
//
